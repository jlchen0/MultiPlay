package com.jchen.multiplay;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.spotify.android.appremote.api.ConnectionParams;
import com.spotify.android.appremote.api.Connector;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.protocol.client.CallResult;
import com.spotify.protocol.client.Result;
import com.spotify.protocol.types.Empty;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity{
    private static final String CLIENT_ID = "93eb2de4eddc4607af07efd1aec9e56a";
    private static final String REDIRECT_URI = "https://google.com";
    private static final String DEV = "Dev";
    private SpotifyAppRemote mSpotifyAppRemote;
    private String lobbyName;
    Handler syncHandler = new Handler();
    Runnable sync = new Runnable(){
        @Override
        public void run(){
            new herokuAppInterface().execute(DEV);
            syncHandler.postDelayed(this, 5000);
            Log.d("Runnable", "Syncing with Heroku.....");
        }
    };
    // private herokuAppInterface connect;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        ConnectionParams connectionParams = new ConnectionParams.Builder(CLIENT_ID)
                .setRedirectUri(REDIRECT_URI)
                .showAuthView(true)
                .build();
        SpotifyAppRemote.connect(this, connectionParams,
                new Connector.ConnectionListener(){
            @Override
            public void onConnected(SpotifyAppRemote spotifyAppRemote){
                mSpotifyAppRemote  = spotifyAppRemote;
                Log.d("MainActivity", "Connected");
                connected();
            }
            @Override
            public void onFailure(Throwable throwable){
                Log.e("MainActivity", throwable.getMessage(), throwable);
            }
        });
        // Continue to refresh and look for songs to add
        Log.d("MainActivity", "Sync");
        syncHandler.post(sync);
    }

    private void connected() {
        // Playing from playlist:

        // Initialize the songs already added to the queue
        new herokuAppInterface().execute(DEV);
        /*
        // Logging info about the current song playing

        mSpotifyAppRemote.getPlayerApi()
                .subscribeToPlayerState()
                .setEventCallback(playerState -> {
                    final Track track = playerState.track;
                    if (track != null) {
                        Log.d("MainActivity", track.name + " by " + track.artist.name);
                    }
                }); */
    }

    private class herokuAppInterface extends AsyncTask<String, Void, String[]>{
        String lobbyName;
        @Override
        protected void onPreExecute(){
            super.onPreExecute();
        }

        @Override
        protected String[] doInBackground(String...url){
            String[] songs = null;
            lobbyName = url[0];
            try{
                InputStream in = new URL("https://multi-play.herokuapp.com/songs/" + lobbyName).openStream();
                JSONArray jsonArr = new JSONArray(IOUtils.toString(in, "UTF-8"));
                songs = new String[jsonArr.length()];
                for (int i = 0; i < jsonArr.length(); i++){
                    Log.d("ReadQueue", "Reading track.");
                    songs[i] = jsonArr.getString(i);
                }
                // Log.d("ReadQueue", IOUtils.toString(in, "UTF-8"));
                in.close();
            } catch(Exception e) {
                e.printStackTrace();
            }
            for (String song: songs){
                CallResult<Empty> callResult = mSpotifyAppRemote.getPlayerApi()
                        .queue(song);
                Result<Empty> result = callResult.await();
                if (result.isSuccessful()){
                    Log.d("ADD_QUEUE", "Added " + song + " to queue.");
                    try {
                        InputStream in = new URL("https://multi-play.herokuapp.com/poll/" + lobbyName).openStream();
                        Log.d("poll", "Polled");
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return songs;
        }
        @Override
        protected void onPostExecute(String[] songs){
            super.onPostExecute(songs);

        }
    }


    @Override
    protected void onPause(){
        super.onPause();
        syncHandler.removeCallbacks(sync);
        syncHandler.post(sync);
    }
    @Override
    protected void onStop() {
        super.onStop();
        SpotifyAppRemote.disconnect(mSpotifyAppRemote);
    }
}